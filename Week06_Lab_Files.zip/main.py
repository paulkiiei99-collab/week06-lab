print("Hello GitHub! This is my Week 06 lab.")
